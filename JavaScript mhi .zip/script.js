



function display( ){
  
  document.querySelector("#omg").innerHTML= " Not available 56754332236790864499 check your network Retry "
  
  
}



